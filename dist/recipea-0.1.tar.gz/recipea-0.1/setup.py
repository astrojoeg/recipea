from setuptools import setup, find_packages

setup(
    name="recipea",
    version="0.1",
    description='reciPY! The Python package for your kitchen.',
    url='https://github.com/astrojoeg/recipea',
    packages=find_packages()
    )
