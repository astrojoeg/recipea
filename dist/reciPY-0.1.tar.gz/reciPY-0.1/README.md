# reciPY
Group 20's Project for Code Astro 2021. This repositoty will help you figure out what you can cook!
